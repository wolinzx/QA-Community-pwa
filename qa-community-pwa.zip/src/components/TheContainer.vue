<template>
    <div class="container">

    </div>
</template>

<script>
export default {
    name: 'TheContainer',
    data () {
        return {
            
        }
    }
}
</script>

<style scoped>
.container{
    margin: 0.5rem 0;
    box-sizing: border-box;
    padding: 0.6rem;
    background: #FFFFFF;
    /* box-shadow: 0 0 1px rgb(133, 133, 133); */
    border: 1px solid #F2F2F2;
}
</style>
