<template>
    <div id="Popular">
        {{msg}}
    </div>
</template>

<script>
export default {
    name: 'Popular',
    
    data () {
        return {
            msg: 'this is Popular '
        }
    }
}
</script>

<style scoped>

</style>


