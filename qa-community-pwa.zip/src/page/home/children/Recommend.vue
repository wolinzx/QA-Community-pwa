<template>
    <div id="recommend">
        {{msg}}

    </div>
</template>

<script>

export default {
    name: 'Recommend',
    data () {
        return {
            msg: 'this is recommend',
        }
    }
}
</script>

<style scoped>

</style>

